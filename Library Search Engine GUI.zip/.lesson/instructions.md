# Instructions  
## Intro

Computer science has been vastly growing as a field to work in due to the high salary of software developers. Therefore, many people flock to it to learn computer programming in hopes to advance their careers, or get a high paying job in the field. In recent years, due to the influx in popularity, tutorials on programming have been on the rise. You are a student attempting to create a library of the all books written in the past few years on programming. You have collected a database of 50,000 books along with their author names for your library.

## Your Task

1. Create a GUI to allow your users to search for books based on the book title, author's first name, last name, gender or the author's unique ID 

2. Display your search results on the screen, and have an interface which allows users to scroll/browse through multiple entries should there exist multiple entries with the same search parameter (e.g. display all authors with the name "Ted"). Display the results alphabetically via their last names.

3. The search result should display all five information fields (first name, last name, gender, UID, and book title).
4. 
5. Have a second page where every author is listed along with all their information in tabular form.

6. Customer retention is VERY IMPORTANT! Your customers are all impatient programmers who don't want to wait for the results to load. Make sure you load your results in the shortest time possible!

7. The data you have is stored in 5 parallel arrays. References are only necessary if you wish to attempt the bonuses.

8. Provide the asymptotic bound for each of the functions
  
9. Every time your application performs an action (such as searching), use performance.now() to record the time it takes to complete the action. Display this number back to the user. 

### Bonus 1 (+3 %)

Hume's copy principle is the theory that all ideas are a copy of an impression. In very much the same way, all the authors in your database are referencing books they've read from the other authors. In your database, each author lists **exactly** 10 other authors' UIDs of whom they've referenced in order to complete their books. 

1. In your interface, when displaying authors one by one, add a list which lists the 10 ten authors that they referenced. 

2. List the referenced author's by their last then first name (i.e. *Last*, *First*).

### Bonus 2 (+7 %)

The **Most Recent Common Ancestor (MRCA)** is a genetics theory which indicates a set of organisms whom are the most recent individuals from which all organisms of a given set are descended (i.e. In plain English, how many tiers of cousins do you have to count upwards until you are considered related to somebody else).

1. Based on the list of authors referenced for each author, create a search field that finds the shortest number of "jumps" it would take to get from the current author to the target author (if possible).

2. If not possible, return not possible.

3. Example: We want to see how many jumps would it take to get from John to Mary. John references Fred, who references George, who references Mary. That would be 3 jumps.


